package dispositivoLavadora;

import dispositivoPadre.DispositivoDigital;

public class Lavadora extends DispositivoDigital {

	private static long rpm; // revoluciones por minuto del tambor de lavadora.
	private static float capacidad; // capacidad en kg del interior del tambor.

	public Lavadora(int peso, double precio, String marca, short consumo, long rpm, float capacidad) {
		super(peso, precio, marca, consumo);
		Lavadora.rpm = rpm;
		Lavadora.capacidad = capacidad;
	}

	/*
	 * Calcula la fuerza necesaria en funcion de la capacidad y revoluciones del tambor.
	 */
	private int dameNivelFuerza() {
		return (int) (rpm * capacidad);
	}
	
	private int dameNumeroEficiencia() {
		return (dameNivelFuerza() / getConsumo());
	}

	@Override
	public char selloEficiencia() {
		if (dameNumeroEficiencia() > 500) {
			return 'S';
		} else if (dameNumeroEficiencia() > 400) {
			return 'A';
		} else if (dameNumeroEficiencia() > 350) {
			return 'B';
		} else if (dameNumeroEficiencia() > 200) {
			return 'C';
		} else if (dameNumeroEficiencia() > 100) {
			return 'D';
		}
		return 'E';
	}

	private String funcionSecado(long rpm) {
		return rpm < 15000 ? "solo lavadora." : "lavadora y secadora.";
	}

	@Override
	public String toString() {
		return String.format("===================\n" + "Lavadora " + this.getMarca() + " || Consumo: [" + getConsumo()
				+ "W] || Funcion " + this.funcionSecado(rpm) + " || Sello Eficiencia [" + this.selloEficiencia()
				+ "] || Peso [" + this.getPeso() + "kg] ||  Precio: [" + this.getPrecio() + "€] || Nº eficiencia: "
				+ this.dameNivelFuerza() + " || NumEfic: " + this.dameNumeroEficiencia());
	}

}